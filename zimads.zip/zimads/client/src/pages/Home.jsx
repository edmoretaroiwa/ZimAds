import { useEffect, useState } from "react";

export default function Home() {
  const [status, setStatus] = useState("checking");
  const [businesses, setBusinesses] = useState([]);

  useEffect(() => {
    fetch("/api/v1/health")
      .then((r) => r.json())
      .then((d) => setStatus(d.status === "ok" ? "online" : "offline"))
      .catch(() => setStatus("offline"));

    fetch("/api/v1/businesses")
      .then((r) => r.json())
      .then((d) => setBusinesses(d.businesses || []))
      .catch(() => setBusinesses([]));
  }, []);

  return (
    <div className="page">
      <section className="hero">
        <h1>Be found by customers in your city.</h1>
        <p className="tagline">
          Post your business on ZimAds and reach people searching for what you sell.
        </p>
        <p className={`status ${status}`}>
          API status: {status === "online" ? "online ✅" : status}
        </p>
      </section>

      <section>
        <h2>Featured businesses</h2>
        {businesses.length === 0 ? (
          <p className="empty">No businesses yet. Start the server to see samples.</p>
        ) : (
          <ul className="list">
            {businesses.map((b) => (
              <li key={b.id} className="item">
                <h3>{b.name}</h3>
                <p>{b.description}</p>
                <small>
                  {b.category}, {b.city}
                </small>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
