# ZimAds

A marketplace where Zimbabwean businesses post their ads.

## Run locally

```bash
pnpm install
pnpm dev
```

- Frontend: http://localhost:5173
- API health: http://localhost:5000/api/v1/health

## Folders

- `client/` React + Vite frontend
- `server/` Express API

## Setup

Copy `server/.env.example` to `server/.env`. Never commit `.env`.
