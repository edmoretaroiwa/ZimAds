import "dotenv/config";
import express from "express";
import cors from "cors";

const app = express();
const PORT = process.env.PORT || 5000;
const CLIENT_URL = process.env.CLIENT_URL || "http://localhost:5173";

app.use(cors({ origin: CLIENT_URL }));
app.use(express.json());

// Sample data until a database is added
const businesses = [
  { id: 1, name: "Mbare Fresh Produce", category: "Food", city: "Harare",
    description: "Vegetables and fruit delivered daily." },
  { id: 2, name: "Bulawayo Auto Care", category: "Cars", city: "Bulawayo",
    description: "Servicing, tyres and repairs." },
  { id: 3, name: "Mutare Print Hub", category: "Services", city: "Mutare",
    description: "Posters, flyers and business cards." },
];

app.get("/api/v1/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

app.get("/api/v1/businesses", (req, res) => {
  res.json({ businesses });
});

app.listen(PORT, () => {
  console.log(`ZimAds API running on http://localhost:${PORT}`);
});
